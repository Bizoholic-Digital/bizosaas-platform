/**
 * useAuth hook
 * Re-export from auth library for convenience
 */

export { useAuth } from '@/lib/auth'
