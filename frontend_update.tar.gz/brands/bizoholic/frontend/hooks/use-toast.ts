/**
 * useToast hook
 * Re-export from UI components for convenience
 */

export * from '@/components/ui/use-toast'
